
<div class="mainHeader backgroundHeader">


        <div class="headerLeftBlock headerPhp">
            <div onclick="window.location.href='http://localhost/DietWEB/index.php'" class="logo">
                <span class="logoLite">Lite</span><span class="logoFit">FIT</span>
            </div>
        </div>

        <div class="headerRightBlock headerPhp">
            <div class="menu">
                <a href="http://localhost/DietWEB/index.php" class="aHome">Strona główna</a>
                <a href="http://localhost/DietWEB/stworzDiete.php" class="aDiet">Stwórz dietę</a>
                <a href="http://localhost/DietWEB/aboutUs.php" class="aAboutUs">O nas</a>
                <a href="http://localhost/DietWEB/contact.php" class="aContact">Kontakt</a>
            </div>
        </div>


</div>




    



