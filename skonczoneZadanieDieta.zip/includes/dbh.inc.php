<?php

    $dbServername = "localhost";
    $dbUsername = "root";
    $dbPassword = "";
    $dbName = "litedietdb";

    $conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);


    // $dbServername = "sql302";
    // $dbUsername = "epiz_31132958";
    // $dbPassword = "wMwzn9kN58t7u";
    // $dbName = "epiz_31132958_litediet";

    // $conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName) or die("Brak bazy danych.");

