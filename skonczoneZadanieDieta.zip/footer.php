
<div class="footer">
    <div class="footerBlok">

        <div class="leftFooter">
            <iframe class="footerMap" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d10098.92886550608!2d20.6141523873676!3d50.7434553489797!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47178e99fd6924cd%3A0xf1839cbee23a321d!2s26-026%20Morawica!5e0!3m2!1spl!2spl!4v1645612524113!5m2!1spl!2spl" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>

        </div>

        <div class="middleFooter">
            <div style="color: #FC9918; font-weight: 400;" class="naglowekSrodek">Adres</div>
            <ul class="listaAdres">
                <li>Morawica 23-982</li>
                <li>Borowikowa 13</li>
                <li>Pon - Sob <b>8:00 - 20:00</b></li>
            </ul>
        </div>
        
        <div class="rightFooter">
            <div style="color: #FC9918; font-weight: 400;" class="naglowekPrawo">Kontakt</div>
            <ul class="listaAdres">
                <li>adres@domena.com</li>
                <li>+48 555 555 555</li>
                <li>Mikołaj Kosiorek</li>
            </ul>
        </div>
                
        <div class="footerRights">
                <hr/>
            © 2022 Copyright by LiteDiet. All rights reserved.
        </div>

    </div>



</div>